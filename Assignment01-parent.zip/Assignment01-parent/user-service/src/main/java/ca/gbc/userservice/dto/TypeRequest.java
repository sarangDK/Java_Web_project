package ca.gbc.userservice.dto;

public record TypeRequest(
        Long type_id,
        String type_name
) {
}
