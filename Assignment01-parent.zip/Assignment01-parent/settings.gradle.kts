rootProject.name = "Assignment01-parent"
include("booking-service","room-service","user-service")