rootProject.name = "event-service"
