rootProject.name = "Assignment01-parent"
include("api-gateway", "approval-service", "booking-service","room-service","user-service","event-service")