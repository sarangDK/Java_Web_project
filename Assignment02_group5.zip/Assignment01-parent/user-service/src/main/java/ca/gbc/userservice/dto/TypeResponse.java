package ca.gbc.userservice.dto;

public record TypeResponse(
        Long type_id,
        String type_name
) {
}
