CREATE DATABASE "room-service";
GRANT ALL PRIVILEGES ON DATABASE "room-service" TO "admin";