CREATE DATABASE "user-service";
GRANT ALL PRIVILEGES ON DATABASE "user-service" TO "admin";